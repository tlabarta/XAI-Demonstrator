# Build an interactive demonstrator for XAI

In this coding challenge, you will create an interactive demo that explains the predictions of a simple neural network using Layer-wise Relevance Propagation (LRP) and Concept Relevance Propagation (CRP).

You are provided with:

- A simple feedforward neural network architecture

- An input image that will be passed through the network

- Code in a Jupyter notebook to generate LRP/CRP heatmaps that explain the network's prediction by assigning relevance scores to the input image pixels/features

- The following sketch of what your future boss thinks he wants:

![](thing_that_your_boss_sketched_in_30_seconds_in_a_meeting.jpg)

Your task is to create an interactive browser-based demo that displays the neural network architecture and allows users to:

- See the input image

- Select neurons in the hidden and output layers

- Generate and display a conditional heatmap from the input image based on the selected neurons

- Highlight the predicted class in the output layer

The demo should be responsive and update in real-time as users select different neurons.
**You are free to choose any frontend frameworks/libraries to create the interactivity, and encouraged to ignore any specifications listed if you think it would generate a better visualization.**
While a polished, production-ready demo is not expected, your demo should be functional and demonstrate your skills. We will discuss your technical and design choices during the interview. 
This demo should showcase your ability to:

- Create engaging, interactive web experiences from a provided codebase and a loose specification.

- Build responsive UIs that react to user input.

- Effectively visualize and explain ML model predictions.

# Set up:

You need to have Python 3.11. You can set up a conda environment, for example, with

    conda create --name demo_hhi python=3.11

and then install the requirements from `requirements.txt` with `pip` (as some are not available in the usual conda channels):

    pip install -r requirements.txt

If you are not familiar with conda, you can also just manually install the dependencies listed.

# Examples:

Run `jupyter notebook` and open the `examples.ipynb` to see how to use the relevant code to run a neural network and to compute the explanations.
Feel free to copy and alter this code as you see fit.
